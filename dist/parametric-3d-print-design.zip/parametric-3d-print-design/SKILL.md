---
name: parametric-3d-print-design
description: "Design 3D-printable parts (enclosures, plates, keycaps, brackets, adapters) as parametric OpenSCAD source with automated validation. Use when a user asks to design a 3D-printable enclosure/case/housing, create CAD models for 3D printing, design a keyboard case or keycaps, produce STL files, work out fit/tolerance/clearance for FDM printing, lay out internal components (PCB, battery, connectors) inside a case, or validate an existing OpenSCAD model. Also use when installing OpenSCAD on a network-restricted machine, or when an STL needs checking for watertightness or dimensional accuracy. Triggers: 3D打印, 建模, 外壳设计, 底座, 定位板, 键帽, 结构设计, 公差, 装配, OpenSCAD, STL, 打印件, 参数化设计."
agent_created: true
---

# Parametric 3D-Print Design

Produce 3D-printable parts as **parametric OpenSCAD source** plus **Python validation
scripts**, rather than hand-modeling or emitting binary STL/STEP directly.

## Why this approach

OpenSCAD source is plain text, so it can be written, diffed, and reviewed precisely.
Binary CAD formats cannot be authored directly by an agent. The workflow is:

1. Write parametric `.scad` source (all dimensions in one `params.scad`)
2. Validate with Python scripts (no CAD toolchain needed)
3. Render to STL with OpenSCAD CLI
4. Verify the STL geometry (bounding box, watertightness)

Steps 2 and 4 catch real errors that source review alone misses.

## Core rules (learned the hard way)

### 1. Never hardcode a dimension that another dimension determines

The single most damaging class of bug. Derive the stack:

```scad
// WRONG — magic number; changing a component silently breaks the assembly
CASE_INNER_H = 9.00;

// RIGHT — derived; changing any component propagates automatically
CASE_INNER_H = PCB_STANDOFF_H + PCB_T + SWITCH_PLATE_GAP;
CASE_OUTER_H = CASE_BOTTOM_T + CASE_INNER_H + PLATE_T;
```

A hardcoded cavity height once made a keyboard's switches unable to reach the PCB —
invisible in source review, fatal in hardware.

Put derived values **after** their dependencies in `params.scad`, or define them at
the end of the file. OpenSCAD resolves variables in source order.

### 2. Unioned parts must overlap, never merely touch

Two solids sharing an exactly coplanar face produce **non-manifold edges** after a
boolean union. The STL is then not watertight and slicers may error or produce thin
walls. Always sink each protruding feature into its parent:

```scad
FUSE_OVERLAP = 0.50;   // push every boss/post/wall 0.5mm into its parent

translate([x, y, CASE_BOTTOM_T - FUSE_OVERLAP])
    cylinder(d = POST_D, h = POST_H + FUSE_OVERLAP);
```

### 3. `rotate([0,90,0])` remaps the axes — offsets included

After rotating a cylinder to lie along X, its local X axis becomes world Z. An offset
written on local X therefore moves the feature **vertically**, not horizontally.

```scad
// WRONG — produces a vertical slot where a horizontal one was intended
rotate([0, 90, 0]) hull() {
    cylinder(d = h, h = len);
    translate([width - h, 0, 0]) cylinder(d = h, h = len);
}

// RIGHT — offset on local Y, which the Y-axis rotation preserves
rotate([0, 90, 0]) hull() {
    cylinder(d = h, h = len);
    translate([0, width - h, 0]) cylinder(d = h, h = len);
}
```

This is hard to spot in source and obvious in a render — another reason to always
render.

### 4. Single source of truth, parsed not duplicated

Validation scripts must **read the parameters out of `params.scad`**, not keep their
own copy. Use `scripts/scad_params.py`. Duplicated constants drift silently.

### 5. Mark documentation-only parameters

Some parameters exist to document a spec (tolerance tables, clearance rules) without
appearing in geometry. Tag them so dead-code checks skip them:

```scad
WIRE_MAX_D = 2.20;    // max wire diameter [spec]
```

## Workflow

### Step 1 — Establish the constraint chain first

Before writing geometry, write out the dimensional chain and the derived stack. For
an enclosure that means: what goes inside, in what order, how thick is each, what
clearance does each need. Convert that chain directly into `params.scad`.

Ask the user for any dimension that cannot be derived or looked up. **One dimension
that genuinely cannot be determined from public sources is normal** — for such a
value, pick a defensible default, mark it clearly, and ship a calibration coupon
(see below).

### Step 2 — Write the model

```
project/
├── cad/
│   ├── lib/params.scad      all dimensions, derived values last
│   ├── <part_a>.scad        one file per printed part
│   ├── <part_b>.scad
│   ├── assembly.scad        exploded view + dimension self-check via echo()
│   └── calibration.scad     test coupon for any unverifiable dimension
└── tools/                   validation scripts
```

Each part file: `include <lib/params.scad>` then modules, then a single top-level
call, then a comment block with print settings.

### Step 3 — Validate before rendering

Run, in order:

```bash
python tools/lint_scad.py        # syntax, cross-file symbols, dead code
python tools/check_dims.py       # design-rule checks on the derived stack
python tools/verify_geometry.py  # hole positions, symmetry, alignment
```

**Keep these three scripts pure Python — no CAD tool dependency.** This matters more
than it looks: the CAD application is often the hardest thing to install (large
download, blocked networks, admin rights). If validation needs it too, the user is
blocked from iterating on the design entirely.

Design the split deliberately:

| Script | Dependency | Why |
|---|---|---|
| lint / design rules / geometry | **pure Python** | Must run anywhere, any time |
| export to STL | CAD application | Only needed to produce printable files |
| verify the exported mesh | **pure Python** | Reads the STL file, not the CAD app |

The consequence is good: a user with only Python can still change dimensions and
confirm the design is sound; they only need the CAD tool when they actually want a
mesh. Ship a `check_env.py` that reports which dependencies are present and what each
one gates, so the user can see they are not blocked.

Read `references/design-rule-checks.md` for the rule list and the implementation
pattern: read params, assert relationships, print PASS/FAIL per rule with a
suggested fix.

**Encode every bug found during development as a permanent check.** A rule written
the moment a bug is understood costs nothing and prevents the same class of error
forever. In practice the rule set grows from ~10 to ~20+ over a project; that growth
is the point, not a smell.

Design rules worth checking for any enclosure: derived-stack consistency, boss-vs-hole
interference, screw/nut engagement length, component clearance, battery/fit thickness,
deflection of any long thin member, and — critically — **full-stroke travel clearance
for every moving part**.

> **Static clearance is not the same as a working mechanism.** A design can pass every
> "parts don't intersect" check and still be unable to move, because the moving part
> bottoms out on something partway through its stroke. Always assert
> `rest_gap >= stroke`, and render the extremes of travel — not just the rest position.
> See `references/design-rule-checks.md` §2b.

### Step 4 — Render

Install OpenSCAD if needed with `scripts/install_openscad.py` (handles blocked
networks; see `references/openscad-pitfalls.md`). Then:

```bash
python tools/export_stl.py
```

### Step 5 — Verify the STL, then look at it

```bash
python tools/verify_stl.py       # bounding box, watertightness, volume, degenerate faces
```

Then **render a PNG and actually look at it**:

```bash
"$OSC" --imgsize=1000,700 --colorscheme=Tomorrow \
       --camera=0,0,0,58,0,32,220 --projection=p --autocenter --viewall \
       -o preview.png part.scad
```

Read the image back. This catches feature-orientation errors (rule 3), features
protruding through walls, and missing cutouts — none of which the numeric checks see.

Render at least: an isometric view, a top view (verify layout), and an axis-aligned
view of every face carrying holes.

### Step 6 — Provide a calibration coupon

For any dimension that depends on a purchased part's actual size (switch height,
connector depth, bearing seat), ship a small test piece printing **several candidate
values in one go**, with instructions to measure the real part against it and feed the
result back. A 15-minute coupon prevents a multi-hour misprint.

## Tolerances for FDM (0.4 mm nozzle)

| Feature | Compensation |
|---|---|
| Holes for fasteners | +0.2 mm per side |
| Press-fit | −0.15 to −0.3 mm per side interference |
| Sliding fit | +0.25 mm per side |
| Connector cutouts | +0.4 mm (err large — too small means it won't plug in) |
| First-layer elephant foot | 0.2 × 45° chamfer at the base |
| Part-to-part clearance | 0.3–0.4 mm |

Print with the hole axis parallel to the bed for the most accurate hole size, and
design so no supports are required (keep overhangs ≤45°, use chamfers not fillets at
downward-facing edges).

## Bundled resources

- `scripts/scad_params.py` — parse numeric parameters out of `params.scad` so
  validation scripts never duplicate constants. Import as a module.
- `scripts/verify_stl.py` — pure-Python STL checker: bounding box vs expected,
  watertightness (every edge shared by exactly 2 triangles), signed volume,
  degenerate triangles. Run after every export.
- `scripts/install_openscad.py` — download and unpack portable OpenSCAD through
  GitHub mirrors with resume support, for networks that block the official site.
- `references/openscad-pitfalls.md` — the full list of traps: variable scoping,
  axis remapping, CSG coplanarity, `$fn` cost, hull/offset behaviour, and the
  network workarounds for installing OpenSCAD.
- `references/design-rule-checks.md` — checklist of design rules to assert for an
  enclosure, with the PASS/FAIL reporting pattern. §13 covers auditing a borrowed
  open-source design before you build on it.

**Adopting someone else's design?** Borrow the electrical part, re-derive the
mechanical part. The hidden risk is never the schematic — it is the unstated
mechanical assumptions (component heights, connector types, pitch, grid-snapped
placement) that silently make it not fit your stack. See §13 of the rules file.

## Reporting to the user

State plainly which dimensions are derived and which were assumed, and which
verifications were actually performed versus skipped. If a render or build could not
be run, say so explicitly rather than implying the model is verified.
