# OpenSCAD pitfalls and environment notes

Traps encountered while building a parametric keyboard case, in rough order of how
much damage they cause.

---

## 1. Variable resolution follows source order

OpenSCAD is not a normal language. Variables resolve **top to bottom**, and a later
assignment overrides an earlier one in the same scope.

```scad
A = B + 1;    // B is undefined here → A is undef
B = 5;
```

Consequences:

- Derived values must be defined **after** everything they reference. Put the total
  height / final assembly dimensions at the **end** of `params.scad`.
- Redefining a variable silently changes every earlier use in a confusing way.
  Treat redefinition as a bug.
- Inside `for` loops, the body is a fresh scope per iteration, so per-iteration
  assignments are safe.

**Detection**: a linter that parses `NAME = expr` lines and reports symbols defined
but never referenced catches most ordering mistakes indirectly.

---

## 2. `rotate()` remaps local axes into world axes

The single most common orientation bug. A rotation applies to the child's whole
coordinate system, including any `translate` offsets written inside it.

```scad
// Intended: a horizontal slot through a wall (slot along Y)
// Actual:   a vertical slot (slot along Z), because local X → world Z
rotate([0, 90, 0])
    hull() {
        cylinder(d = 4, h = 10);
        translate([6, 0, 0]) cylinder(d = 4, h = 10);
    }
```

Rotation axis → mapping (for a 90° rotation):

| Rotation | local X becomes | local Y becomes | local Z becomes |
|---|---|---|---|
| `rotate([0, 90, 0])` | world −Z | world Y | world X |
| `rotate([90, 0, 0])` | world X | world −Z | world Y |

Rule of thumb: to keep a feature horizontal after rotating a cylinder onto the X
axis, offset it along **local Y**.

**Detection**: numeric checks cannot see this. Only a render (or an axis-aligned
orthographic view of the affected face) reveals it.

---

## 3. Coplanar boolean unions produce non-manifold meshes

A `union()` of two solids that share an exactly coincident face yields edges shared
by more than two triangles. The STL is not watertight; slicers may error, repair
silently, or emit a zero-thickness wall.

```scad
// Fragile — post base exactly on the plate top surface
translate([x, y, BOTTOM_T]) cylinder(d = 5, h = 20);

// Robust — sink it in
FUSE_OVERLAP = 0.5;
translate([x, y, BOTTOM_T - FUSE_OVERLAP]) cylinder(d = 5, h = 20 + FUSE_OVERLAP);
```

Apply this to every boss, post, rib, wall and pad that grows out of another solid.
0.4–0.6 mm is plenty; it disappears inside the parent.

**Detection**: `scripts/verify_stl.py` reports edges not shared by exactly two
triangles. Expect 0 for a single connected solid.

---

## 4. `$fn` multiplies everything downstream

`$fn` is a global tessellation setting. Setting `$fn = 64` at the top of a params
file applies to every cylinder and every curved surface in the model, including ones
inside boolean operations. Large values make CGAL previews and renders very slow.

Use a moderate value (32–64) for design iteration and only raise it for the final
export if the surface quality requires it. A better option is to set `$fn` per
feature for the few surfaces that are actually visible.

---

## 5. `offset()` needs a closed 2D shape, and radius sign matters

`offset(r = x)` rounds outward; `offset(delta = x)` offsets by a distance with sharp
corners. To make a rounded rectangle from a square:

```scad
offset(r = r) offset(delta = -r) square([w, h]);
```

The double offset is required: the inner `offset(delta = -r)` shrinks, the outer
`offset(r = r)` rounds. Using only `offset(r = r)` grows the shape by `r` on every
side, silently changing the intended size.

`offset()` only works on 2D shapes. Wrap with `linear_extrude()` for 3D.

---

## 6. `hull()` of translated children uses their positions

`hull()` computes the convex hull of all children **at their translated positions**,
which makes it the right tool for tapers and slots:

```scad
// A tapered shell: hull of a bottom square and a smaller raised top square
hull() {
    linear_extrude(height = 0.01) square([w_bot, d_bot], center = true);
    translate([0, 0, h - t])
        linear_extrude(height = t) square([w_top, d_top], center = true);
}
```

But it is a convex operation: it cannot produce concave results, and hulling two
overlapping children is wasteful. For slots, hull two circles.

---

## 7. `difference()` order and degenerate results

Subtracting a shape that exactly matches a face can leave zero-thickness geometry.
Extend every cutter slightly past the surface it cuts (0.01–1 mm) so the subtraction
is unambiguous.

Also beware subtracting a cutter that leaves a zero-area sliver: the result may
contain degenerate triangles. `scripts/verify_stl.py` counts these; a handful is
normal, hundreds indicate a modelling problem.

---

## 8. Comment syntax inside `params.scad` and the `[spec]` convention

OpenSCAD comments are `//` and `/* */`. Use them liberally — the params file doubles
as documentation.

Some parameters document a specification rather than drive geometry (tolerance
tables, clearance rules, purchased-part dimensions). Tag these so dead-code checks do
not flag them:

```scad
WIRE_MAX_D = 2.20;    // max wire diameter [spec]
```

---

## 9. Installing OpenSCAD when the network blocks it

Symptoms encountered:

| Attempt | Result |
|---|---|
| Direct download from `files.openscad.org` | TLS error `0x80072f19` |
| `winget install` (default source) | Same TLS failure |
| `winget install --source winget` | Same |
| GitHub Release URL, direct | Redirects to `objects.githubusercontent.com` → `CONNECT tunnel failed, response 502` |
| GitHub API (`api.github.com`) | **Works** — useful for discovering asset names |
| GitHub mirror prefix `https://ghproxy.net/` + `curl -C -` | **Works** |

The mirror approach was slow (~20 KB/s for a 20 MB archive) and needed three resumed
attempts. Always use `curl -C -` so a dropped connection continues rather than
restarting.

`scripts/install_openscad.py` automates this: it tries several mirror prefixes in
order, resumes, validates the zip, extracts, and locates the executable.

### Prefer the console binary on Windows

The zip contains both `openscad.exe` (GUI) and `openscad.com` (console). For CLI
rendering use **`openscad.com`** — it does not open a window and behaves properly
when invoked from a script.

### Useful CLI invocations

```bash
# Version check
openscad.com --version

# Export STL
openscad.com -o out.stl part.scad

# Override a variable (note the quoting for strings)
openscad.com -D 'mode="4u"' -o out.stl part.scad

# Render a PNG preview — read the image back to inspect it
openscad.com --imgsize=1000,700 --colorscheme=Tomorrow \
             --camera=0,0,0,58,0,32,220 --projection=p \
             --autocenter --viewall -o preview.png part.scad
```

`--camera` is `tx,ty,tz,rx,ry,rz,dist`. With `--autocenter --viewall` the translation
is ignored and only the rotations and distance matter. `--projection=o` is
orthographic — use it for axis-aligned verification views (top view to check a
layout, side view to check a hole's orientation).

### `echo()` is the cheapest self-check

`echo()` output appears on stdout during CLI rendering. Use it to print the derived
dimension chain so every render reports the numbers it actually built:

```scad
echo(str("inner height = ", CASE_INNER_H, " mm"));
```

This makes a silently-broken derived value visible in the build log.
