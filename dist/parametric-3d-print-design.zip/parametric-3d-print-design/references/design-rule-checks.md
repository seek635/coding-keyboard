# Design-rule checks for a 3D-printed enclosure

A checklist of relationships to assert programmatically before printing. Each rule
below corresponds to a bug that actually shipped in a first draft and was caught only
when the rule was written down.

Write these as a script that **reads `params.scad`** (via `scad_params.py`), prints
PASS/FAIL per rule, and exits non-zero on failure. Example reporting shape:

```python
results = []

def chk(name, ok, detail, fix=""):
    results.append((name, ok, detail, fix))

chk("cavity height matches component stack",
    abs(CASE_INNER_H - (SUPPORT + PCB_T + GAP)) < 0.001,
    f"{CASE_INNER_H:.2f} vs {SUPPORT + PCB_T + GAP:.2f}",
    "derive CASE_INNER_H, do not hardcode it")

for name, ok, detail, fix in results:
    print(("✅" if ok else "❌"), name, detail)
    if not ok and fix:
        print("   └ fix:", fix)

if any(not ok for _, ok, _, _ in results):
    sys.exit(1)
```

Exiting non-zero makes the check usable in a pipeline.

---

## 1. Derived stack consistency

**Assert** every "total" equals the sum of its parts.

- Cavity height == sum of the layers it contains
- Overall height == base + cavity + top plate
- Any value that appears in two places must be computed once

**The bug it catches**: a hardcoded cavity height that left the internal mechanism
unable to reach its mating surface. Source review passed; the hardware would not
assemble.

---

## 2. Moving part reach

**Assert** each moving or mating part can physically span the gap it must cross.

For a switch/connector seated below a plate: the part's below-plate length must equal
the PCB-to-plate gap within a small tolerance. If the gap is larger, the part floats;
if smaller, it cannot seat.

Also assert the inverse: the part's protrusion above the plate must be **less than**
the receiving pocket depth plus any clearance, or it will bottom out and burst through.

### 2b. Full-stroke travel — the check that static clearance misses

**This is a separate rule from "parts don't intersect", and it is easy to miss.**

Assert that any part which moves can complete its **entire** stroke without colliding.

```python
# The button must descend a full stroke before anything hits anything else.
assert cap_bottom_to_plate >= actuator_travel, \
    "button bottoms out on the housing before the switch actuates"
```

A real failure: a keycap sat 0.3 mm above the plate while the switch needed 3.0 mm of
travel. Every static clearance check passed — nothing intersected at rest — but the key
could only move 0.3 mm before its skirt hit the plate, so it was effectively unpressable.

The trap is that the moving part's **widest** feature is often what collides, not the
part nearest the obstruction. Here the keycap's skirt (17.6 mm) was wider than the hole
in the plate (13.8 mm), so it could not descend into the hole — it had to clear the
plate's top surface entirely.

Two rules to write:

1. **Travel clearance**: `rest_gap >= stroke`
2. **Engagement**: the driven part must still reach its coupling at rest —
   `rest_gap + socket_depth >= protrusion`

Both must hold simultaneously; they push in opposite directions and set the minimum
height of the assembly.

**Static checks cannot find this class of error.** Neither can reading the source. It
shows up when you render the assembly and look at whether the mechanism can actually
operate — or when a user asks "wait, how does this even move?". Render the extremes of
travel, not just the rest position.

---

## 3. Boss / post versus hole interference

**Assert** no structural post overlaps a cutout.

Compute the nearest hole edge and the post's outer edge along the axis that separates
them; require ≥0.8 mm clearance.

**The bug it catches**: posts placed at a fixed inset that collided with the corner
cutouts, because the pitch minus the cutout left only ~4 mm between holes — less than
a post needs. The fix was to widen the border, not to shrink the post.

> General lesson: when the inter-hole gap is smaller than a fastener needs, put the
> fasteners **outside** the hole grid and widen the border. Do not thin the post.

---

## 4. Fastener engagement

For a screw into a printed post:

**Assert** `thread_depth_available >= screw_thread_length` and that the tap hole does
not break through the far wall unless intended.

Typical values: M2 self-tapping into PLA needs a 1.7 mm pilot; a blind hole should
leave at least 1 mm of material at the bottom.

For a nut on a threaded bushing passing through a panel:

**Assert** `panel_thickness + boss_thickness + nut_thickness <= bushing_length`.
This one is easy to miss because the bushing length is a purchased-part dimension and
the boss thickness is derived from it — a circular dependency. Resolve by deriving the
boss thickness from the bushing length:

```scad
BOSS_T = max(2.0, BUSH_LEN - WALL_T - NUT_T - 0.5);
```

---

## 5. Protruding features stay inside the envelope

**Assert** any feature added to an outer face fits within the part's height/width.

A boss centred on a face extends `diameter/2` in every direction from its centre.
Check both bounds.

**The bug it catches**: a boss sized from the switch's panel footprint (19 mm) centred
at mid-height on a 14.8 mm tall case — it protruded through both the top and bottom.

---

## 6. Component clearances

**Assert** for each internal component:

- Its thickness plus any adhesive tape fits the allocated layer
- It does not overlap another component in the same layer (compare footprints)
- Heat-generating parts have clearance to the walls and are separated from
  heat-sensitive parts (batteries)
- Parts needing external access (connectors) are within reach of their cutout

A useful derived check: `available_thickness = layer_height - tape_thickness`, then
`assert battery_thickness <= available_thickness`.

---

## 7. Cable routing

**Assert** channel cross-section exceeds the largest cable diameter with margin, and
that channels do not pass through component footprints or cutouts.

Document the maximum cable diameter as a `[spec]` parameter even if it does not drive
geometry, so the number is recorded next to the channel dimensions.

---

## 8. Long unsupported members

**Assert** the deflection of any long thin member under a realistic load is acceptable.

Cantilever / simply-supported midpoint deflection: `δ = F·L³ / (48·E·I)` with
`I = b·t³/12`.

Use the **unribbed** section thickness for the worst case even if ribs are modelled —
ribs are often interrupted and contribute less than a uniform thickness would suggest.
For PLA, `E ≈ 2400 MPa`.

A threshold around 0.5 mm at a 3 N point load is a reasonable pass mark for a keycap;
anything above 1 mm is perceptible as a mushy key.

This check is what justified adding a third support under a long key: single support
gave 1.6 mm, three supports gave 0.2 mm.

---

## 9. Fit between mating printed parts

**Assert** clearances are positive and within the intended class:

| Interface | Target |
|---|---|
| Drop-in / location | +0.15 to +0.25 mm per side |
| Sliding | +0.25 to +0.4 mm per side |
| Press / interference | −0.15 to −0.3 mm per side |

Also check that a part which must drop into a cavity is smaller than the cavity by
the specified clearance **on every side**, including where a corner radius reduces
the effective opening.

---

## 10. Self-check the reported totals

Have the render itself print the derived chain via `echo()`. If a derived value is
silently wrong, the build log shows it. Pair this with the Python checks: the Python
side proves the relationships hold, the `echo()` side proves the rendered model used
those values.

---

## 11. Verify the exported mesh

After export, assert per part:

- Bounding box matches the design within ~0.6 mm
  (remember to account for features that legitimately extend beyond the nominal
  envelope — bosses, chamfers)
- Watertight: every edge shared by exactly two triangles (0 exceptions for a single
  connected solid)
- Volume positive and plausible (a negative volume means inverted normals)
- Degenerate triangle count is small (single digits, not hundreds)

See `scripts/verify_stl.py`.

---

## 12. Cross-check derived artefacts against the source of truth

If the project produces anything besides the CAD model that encodes the same
structure — a firmware keymap, a wiring table, a bill of materials — validate them
against the model's parameter file rather than trusting them to be kept in sync.

In the keyboard project, a script compared the CAD key list against the firmware
keymap position by position and caught drift immediately. Without it, changing the
layout in CAD and forgetting the firmware would have produced a keyboard whose keys
did the wrong things.

Prefer this over a note in the README asking people to remember.
